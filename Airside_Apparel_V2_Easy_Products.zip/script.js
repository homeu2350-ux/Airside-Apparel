/*
===========================================================
AIRSIDЕ APPAREL — PRODUCT LIST
===========================================================

TO ADD A PRODUCT:
1. Put its image in: assets/products/
2. Copy one product object below.
3. Change only the name, price, description and image.

Example:
{
  name: "Airside New Hoodie",
  price: 70,
  description: "Black / Founder-inspired design",
  image: "new-hoodie.jpg"
}

The website automatically creates the product card and
adds the product to the order form.
===========================================================
*/

const products = [
  {
    name: "Airside Signature Hoodie",
    price: 65,
    description: "Black / White",
    image: "signature-hoodie.jpg"
  },
  {
    name: "Airside Crewneck",
    price: 55,
    description: "Black / Minimal Logo",
    image: "crewneck.jpg"
  },
  {
    name: "Airside Classic Tee",
    price: 35,
    description: "Premium everyday fit",
    image: "classic-tee.jpg"
  }
  // ADD NEW PRODUCTS HERE
];

const ownerEmail = "YOUR_EMAIL_HERE@example.com";

function productImage(product) {
  if (!product.image) return "";
  return `assets/products/${product.image}`;
}

function renderProducts() {
  const container = document.getElementById("products");
  const select = document.getElementById("product");

  container.innerHTML = "";
  select.innerHTML = '<option value="">Select a product</option>';

  products.forEach((product, index) => {
    const card = document.createElement("article");
    card.className = "product";

    const imagePath = productImage(product);

    card.innerHTML = `
      <div class="product-art">
        <img src="${imagePath}" alt="${product.name}" onerror="this.style.display='none'; this.parentElement.classList.add('no-image');">
        <div class="image-fallback">
          <span>A</span>
          <small>AIRSIDE APPAREL</small>
        </div>
      </div>
      <div class="product-info">
        <div>
          <h3>${product.name}</h3>
          <p>${product.description}</p>
        </div>
        <strong>$${product.price}</strong>
      </div>
      <button class="product-btn" onclick="orderProduct(${index})">Request to Buy</button>
    `;

    container.appendChild(card);

    const option = document.createElement("option");
    option.value = product.name;
    option.textContent = `${product.name} — $${product.price}`;
    select.appendChild(option);
  });
}

function orderProduct(index) {
  document.getElementById("product").value = products[index].name;
  document.getElementById("contact").scrollIntoView({behavior: "smooth"});
}

function sendOrder(event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const product = document.getElementById("product").value;
  const size = document.getElementById("size").value;
  const message = document.getElementById("message").value.trim();

  if (ownerEmail.includes("YOUR_EMAIL_HERE")) {
    alert("Open script.js and replace YOUR_EMAIL_HERE@example.com with your business email first.");
    return;
  }

  const subject = encodeURIComponent(`Airside Apparel Order Request — ${product}`);
  const body = encodeURIComponent(
`New Airside Apparel order request

Name: ${name}
Email: ${email}
Product: ${product}
Size: ${size}

Message:
${message || "No additional message."}`
  );

  window.location.href = `mailto:${ownerEmail}?subject=${subject}&body=${body}`;
}

document.getElementById("year").textContent = new Date().getFullYear();
renderProducts();
