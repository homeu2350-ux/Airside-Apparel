AIRSIDE APPAREL V2 — EASY PRODUCT SYSTEM
===========================================

NO NODE.JS REQUIRED.
NO DATABASE REQUIRED.
NO MONTHLY WEBSITE BUILDER REQUIRED.

The important folders are:

assets/
  logo.png

assets/products/
  PUT ALL PRODUCT IMAGES HERE

TO ADD A PRODUCT
----------------
1. Put the product picture inside:
   assets/products/

   Example:
   assets/products/aviation-hoodie.jpg

2. Open:
   script.js

3. Find:
   const products = [

4. Add one object:

{
  name: "Aviation Hoodie",
  price: 70,
  description: "Black / White",
  image: "aviation-hoodie.jpg"
}

5. Save.

That's it.

The website automatically creates:
- The product card
- Product image
- Product name
- Price
- Description
- Request to Buy button
- Product in the order form

IMAGE TIPS
----------
JPG, PNG and WEBP are good choices.
Use product pictures with the clothing centered.
Around 1000x1000 or 1200x1500 works well.

EMAIL
-----
Open script.js and change:

const ownerEmail = "YOUR_EMAIL_HERE@example.com";

to your business email.

The current ordering system opens the customer's email app.
It doesn't process payments.

FILES
-----
index.html  = website structure
styles.css  = design
script.js   = products + ordering
assets/     = logo
assets/products/ = every product image

TO PREVIEW
----------
Open index.html in a browser, or use Live Server in VS Code.

TO CHANGE YOUR PRODUCTS LATER
-----------------------------
You do NOT need to edit index.html.

Only:
1. Add the image to assets/products/
2. Add one tiny product object to script.js

That is the entire product workflow.
